"""Transcript integration point for speech_context_recovery.

Replace this stub with the teammate's transcription implementation.
"""

def transcript(video_path: str) -> list[dict]:
    """Return timestamped transcript segments (timestamps in seconds).

    See speech_context_recovery.transcript for the complete interface contract.
    """
    raise NotImplementedError("Connect the project's transcription provider")
