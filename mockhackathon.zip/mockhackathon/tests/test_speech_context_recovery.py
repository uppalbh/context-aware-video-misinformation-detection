import subprocess
from pathlib import Path

import pytest

import speech_context_recovery as scr


def test_context_intervals_multiple_reordered_adjacent_overlap_and_tail():
    matches = [
        scr.Match(scr.EditedClip(0, 2), 8, 10, .9, "audio"),
        scr.Match(scr.EditedClip(2, 4), 2, 4, .9, "audio"),
        scr.Match(scr.EditedClip(4, 6), 4, 6, .9, "audio"),
        scr.Match(scr.EditedClip(6, 8), 3.5, 5, .9, "audio"),
    ]
    ordered = scr.resolve_duplicate_and_overlapping_matches(matches)
    gaps = scr.identify_missing_context(ordered[:3], 12, tail_seconds=30)
    assert [(round(x.start, 1), round(x.end, 1)) for x in gaps] == [(6, 8), (10, 12)]


def test_head_short_gap_tail_shorter_than_config_and_clip_edges():
    matches = [scr.Match(scr.EditedClip(0, 2), 1, 3, .9, "transcript"),
               scr.Match(scr.EditedClip(2, 4), 3.5, 5, .9, "transcript")]
    gaps = scr.identify_missing_context(matches, 8, min_gap=1, tail_seconds=30, include_head=True)
    assert [(x.start, x.end) for x in gaps] == [(0.0, 1), (5, 8)]
    assert scr.identify_missing_context([scr.Match(scr.EditedClip(0, 2), 0, 2, .9, "audio")],
                                        4, tail_seconds=30) == [scr.ContextClip(2, 4)]


def test_unmatched_clips_are_omitted_from_gap_computation():
    known = [scr.Match(scr.EditedClip(0, 3), 2, 5, .9, "audio"),
             scr.Match(scr.EditedClip(3, 6), 10, 13, .9, "audio")]
    assert scr.identify_missing_context(known, 20, tail_seconds=2) == [
        scr.ContextClip(5, 10), scr.ContextClip(13, 15)]


def test_frame_snap_and_five_minute_segmentation(monkeypatch):
    monkeypatch.setattr(scr, "detect_scene_boundaries", lambda *_: [])
    spans = scr.segment_edited_video("edited.mp4", 605, True)
    assert spans[0].start == 0 and spans[-1].end == 605
    assert all(2 <= s.duration <= 300 for s in spans)
    assert len(spans) == 3
    assert scr.segment_edited_video("edited.mp4", 2, False) == [scr.EditedClip(0, 2)]
    a, b = scr.refine_match_timestamps(1.01, 2.02, 10, 25)
    assert a == pytest.approx(1.0) and b == pytest.approx(3.0)


def test_repeated_phrases_preserve_multiple_transcript_candidates():
    repeated = "we shall overcome"
    source = [{"start": n, "end": n + 1, "words": [
        {"word": word, "start": n + i * .2, "end": n + (i + 1) * .2}
        for i, word in enumerate(repeated.split())]}
        for n in (1, 8)]
    query = [{"start": 0, "end": .6, "text": repeated}]
    candidates = scr._transcript_candidates(query, source, 2)
    assert len(candidates) == 2
    assert candidates[0][1] >= .99 and candidates[1][1] >= .85
    assert {round(start) for start, _ in candidates} == {1, 8}


def test_transcript_alignment_survives_errors_and_weak_audio(monkeypatch):
    monkeypatch.setattr(scr, "_audio_candidates", lambda *_: [(0.0, .1)])
    monkeypatch.setattr(scr, "_transcript_candidates", lambda *_: [(4.0, .8)])
    monkeypatch.setattr(scr, "_phash_candidates", lambda *_: [])
    info = scr.VideoInfo("original.mp4", 10, 25, 640, 360, 16000, 1, True, True)
    result = scr.match_clip_to_original("clip.mp4", scr.EditedClip(0, 2), info,
                                        [{"text": "the quick brown fox"}],
                                        [{"text": "quick brown foxx", "start": .1, "end": 2}], True)
    assert result is not None and result.method == "transcript"
    assert result.original_start == pytest.approx(4)


def test_unmatchable_clip_is_rejected(monkeypatch):
    monkeypatch.setattr(scr, "_audio_candidates", lambda *_: [])
    monkeypatch.setattr(scr, "_transcript_candidates", lambda *_: [])
    monkeypatch.setattr(scr, "_phash_candidates", lambda *_: [])
    info = scr.VideoInfo("original.mp4", 10, 25, 640, 360, 16000, 1, True, True)
    assert scr.match_clip_to_original("clip.mp4", scr.EditedClip(0, 2), info, [], [], True) is None


@pytest.fixture
def tiny_media(tmp_path):
    """Create a short synthetic source and a 3-second cut with known timestamps."""
    source = tmp_path / "source.mp4"
    edited = tmp_path / "edited.mp4"
    subprocess.run([
        "ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i",
        "testsrc2=size=160x90:rate=25:duration=10", "-f", "lavfi", "-i",
        "sine=frequency=440:sample_rate=16000:duration=10", "-c:v", "libx264", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-shortest", str(source)
    ], check=True)
    subprocess.run([
        "ffmpeg", "-y", "-v", "error", "-ss", "3", "-i", str(source), "-t", "3",
        "-c", "libx264", "-c:a", "aac", str(edited)
    ], check=True)
    return source, edited


def test_synthetic_video_probe_and_export_have_audio_video(tiny_media, tmp_path):
    source, _ = tiny_media
    info = scr.inspect_video(str(source))
    assert info.has_video and info.has_audio and info.duration == pytest.approx(10, abs=.2)
    output = tmp_path / "out.mp4"
    scr.extract_clip(str(source), 1, 4, str(output))
    scr._probe_output(str(output))
    assert output.is_file()


def test_audio_matching_finds_synthetic_subclip(tiny_media):
    source, edited = tiny_media
    info = scr.inspect_video(str(source))
    clip = scr.EditedClip(0, 3)
    result = scr.match_clip_to_original(str(edited), clip, info, [], [], True)
    # This synthetic has repeating tone audio, so visual frames corroborate the
    # estimate; allow several frames for encoding and feature-window offsets.
    assert result is not None
    assert result.original_start == pytest.approx(3, abs=1.0)


def test_transcript_errors_and_timestamp_drift_do_not_crash(tiny_media, tmp_path):
    source, edited = tiny_media
    calls = []
    def provider(path):
        calls.append(path)
        if Path(path) == source:
            return [{"start": 0, "end": 10, "text": "alpha bravo charlie delta echo foxtrot"}]
        raise RuntimeError("mock provider unavailable")
    # Provider errors degrade to audio; the contract is called once for each input clip.
    outputs = scr.recover(str(source), str(edited), str(tmp_path / "exports"), transcript_fn=provider,
                          tail_seconds=0)
    assert len(calls) == 2
    assert outputs


def test_missing_audio_is_supported(tmp_path):
    silent = tmp_path / "silent.mp4"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i",
                    "testsrc2=size=128x72:rate=25:duration=4", "-c:v", "libx264", "-pix_fmt",
                    "yuv420p", str(silent)], check=True)
    info = scr.inspect_video(str(silent))
    assert info.has_video and not info.has_audio
    out = tmp_path / "with-silence.mp4"
    scr.extract_clip(str(silent), 0, 3, str(out), source_has_audio=False)
    scr._probe_output(str(out))
