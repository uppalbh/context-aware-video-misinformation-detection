#!/usr/bin/env python3
"""Recover the source intervals and omitted context from an edited speech MP4.

Transcript contract (the provider is separate and injectable):

    transcript(video_path: str) -> list[dict]

Each segment has ``start`` and ``end`` floats in seconds relative to the file,
``text``, and optionally ``words`` containing ``word``, ``start`` and ``end``.
Segments are sorted by start time. Expect missing/substituted words and timestamp
errors of roughly 1–2 seconds. The original is transcribed once and each
segmented edited clip once; provider failures degrade to other match signals.
"""
from __future__ import annotations

import argparse
import json
import logging
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, Optional

import numpy as np

LOG = logging.getLogger("speech_context_recovery")
MAX_CLIP = 300.0
MIN_CLIP = 2.0


@dataclass(frozen=True)
class VideoInfo:
    path: str
    duration: float
    fps: float
    width: int
    height: int
    audio_rate: int
    audio_channels: int
    has_video: bool
    has_audio: bool


@dataclass(frozen=True)
class EditedClip:
    start: float
    end: float

    @property
    def duration(self) -> float:
        return self.end - self.start


@dataclass
class Match:
    clip: EditedClip
    original_start: float
    original_end: float
    confidence: float
    method: str


@dataclass(frozen=True)
class ContextClip:
    start: float
    end: float


def _run(command: list[str], *, capture: bool = True) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(command, check=True, text=True,
                              stdout=subprocess.PIPE if capture else subprocess.DEVNULL,
                              stderr=subprocess.PIPE if capture else subprocess.DEVNULL)
    except FileNotFoundError as exc:
        raise RuntimeError(f"Required executable not found: {command[0]}") from exc
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or "").strip()
        raise RuntimeError(f"Command failed ({command[0]}): {detail[-1200:]}") from exc


def inspect_video(video_path: str) -> VideoInfo:
    """Probe streams, duration and media properties; reject unreadable inputs."""
    path = str(Path(video_path).expanduser().resolve())
    if not Path(path).is_file():
        raise FileNotFoundError(f"Video does not exist: {path}")
    result = _run(["ffprobe", "-v", "error", "-show_streams", "-show_format",
                   "-of", "json", path])
    try:
        data = json.loads(result.stdout)
        streams = data.get("streams", [])
        video = next((s for s in streams if s.get("codec_type") == "video"), None)
        audio = next((s for s in streams if s.get("codec_type") == "audio"), None)
        duration = float((video or {}).get("duration") or data.get("format", {}).get("duration"))
        if not math.isfinite(duration) or duration <= 0:
            raise ValueError("missing/invalid duration")
        fps_text = (video or {}).get("avg_frame_rate", "0/1")
        n, _, d = fps_text.partition("/")
        fps = float(n) / max(float(d or 1), 1.0)
        return VideoInfo(path, duration, fps if fps > 0 else 25.0,
                         int((video or {}).get("width", 0)), int((video or {}).get("height", 0)),
                         int((audio or {}).get("sample_rate", 0)),
                         int((audio or {}).get("channels", 0)), video is not None, audio is not None)
    except (ValueError, TypeError, StopIteration) as exc:
        raise ValueError(f"Cannot read valid media streams from {path}: {exc}") from exc


def _scene_boundaries(video_path: str) -> list[float]:
    cuts: set[float] = set()
    try:
        from scenedetect import open_video, SceneManager
        from scenedetect.detectors import ContentDetector, AdaptiveDetector
        scene_manager = SceneManager()
        scene_manager.add_detector(ContentDetector(threshold=30.0, min_scene_len=15))
        scene_manager.add_detector(AdaptiveDetector(adaptive_threshold=3.0, min_scene_len=15))
        scene_manager.detect_scenes(video=open_video(video_path))
        cuts.update(float(start.get_seconds()) for start, _ in scene_manager.get_scene_list()[1:])
    except Exception as exc:
        LOG.warning("PySceneDetect could not find scene cuts (%s); using signal boundaries", exc)
    return sorted(cuts)


def _decode_audio(path: str, rate: int = 8000) -> np.ndarray:
    raw = _run(["ffmpeg", "-v", "error", "-i", path, "-vn", "-ac", "1", "-ar", str(rate),
                "-f", "f32le", "-"]).stdout
    return np.frombuffer(raw.encode("latin1"), dtype=np.float32) if isinstance(raw, str) else np.frombuffer(raw, dtype=np.float32)


def _audio_discontinuities(path: str, has_audio: bool) -> list[float]:
    if not has_audio:
        return []
    # Decode to a temporary raw file because Python's text subprocess wrapper is
    # deliberately used for ffprobe; raw PCM must remain binary.
    with tempfile.TemporaryDirectory(prefix="speechcuts-") as td:
        pcm = Path(td) / "audio.f32"
        _run(["ffmpeg", "-y", "-v", "error", "-i", path, "-vn", "-ac", "1", "-ar", "8000",
              "-f", "f32le", str(pcm)])
        x = np.fromfile(pcm, dtype=np.float32)
    if x.size < 16000:
        return []
    frame = 800
    usable = x[: x.size // frame * frame].reshape(-1, frame)
    rms = np.sqrt(np.mean(usable * usable, axis=1) + 1e-12)
    # Find abrupt energy transitions only when both adjacent windows are audible.
    ratio = np.maximum(rms[1:], rms[:-1]) / (np.minimum(rms[1:], rms[:-1]) + 1e-8)
    idx = np.flatnonzero((ratio > 7.0) & (np.maximum(rms[1:], rms[:-1]) > 0.008)) + 1
    # Keep separated candidates to avoid splitting on every syllable transient.
    out: list[float] = []
    for i in idx:
        t = float(i) * 0.1
        if not out or t - out[-1] >= 2.0:
            out.append(t)
    return out


def detect_scene_boundaries(edited_path: str, has_audio: bool = True) -> list[float]:
    """Return candidate cuts from PySceneDetect plus abrupt audio-energy jumps."""
    return sorted(set(_scene_boundaries(edited_path) + _audio_discontinuities(edited_path, has_audio)))


def segment_edited_video(edited_path: str, duration: float, has_audio: bool = True) -> list[EditedClip]:
    """Build bounded clip intervals from scene/audio cut candidates.

    Short scene cuts are merged into their neighbor; long spans are subdivided
    at the configured five-minute maximum. A detected cut is only a proposal:
    source timeline continuity is checked after matching and adjacent source
    ranges remain gap-free in the final output.
    """
    # Avoid creating a sub-two-second fragment at either file edge.
    cuts = [t for t in detect_scene_boundaries(edited_path, has_audio)
            if MIN_CLIP <= t <= duration - MIN_CLIP]
    points = [0.0] + cuts + [duration]
    spans: list[EditedClip] = []
    for left, right in zip(points, points[1:]):
        if spans and right - left < MIN_CLIP:
            prev = spans.pop()
            spans.append(EditedClip(prev.start, right))
            continue
        if right - left >= MIN_CLIP:
            spans.append(EditedClip(left, right))
    bounded: list[EditedClip] = []
    for span in spans:
        count = max(1, math.ceil(span.duration / MAX_CLIP))
        for i in range(count):
            a = span.start + span.duration * i / count
            b = span.start + span.duration * (i + 1) / count
            if b - a >= MIN_CLIP:
                bounded.append(EditedClip(a, b))
    return bounded


def _extract_audio_array(path: str, rate: int = 8000) -> np.ndarray:
    with tempfile.TemporaryDirectory(prefix="speech-audio-") as td:
        pcm = Path(td) / "audio.f32"
        _run(["ffmpeg", "-y", "-v", "error", "-i", path, "-vn", "-ac", "1", "-ar", str(rate),
              "-f", "f32le", str(pcm)])
        return np.fromfile(pcm, dtype=np.float32)


def _spectrum_features(samples: np.ndarray, rate: int = 8000, hop: int = 800) -> np.ndarray:
    """Gain-normalized log-spectrum vectors, one vector every 100 ms."""
    win = 2048
    if len(samples) < win:
        return np.empty((0, 32), dtype=np.float32)
    starts = np.arange(0, len(samples) - win + 1, hop)
    windows = np.stack([samples[s:s + win] for s in starts]) * np.hanning(win).astype(np.float32)
    spec = np.abs(np.fft.rfft(windows, axis=1))
    # Pool spectral bins into 32 logarithmically spaced bands.
    edges = np.unique(np.geomspace(2, spec.shape[1], 33).astype(int))
    feat = np.stack([np.log1p(spec[:, edges[i]:edges[i + 1]].mean(axis=1))
                     for i in range(len(edges) - 1)], axis=1)
    feat -= feat.mean(axis=1, keepdims=True)
    norm = np.linalg.norm(feat, axis=1, keepdims=True)
    return (feat / np.maximum(norm, 1e-6)).astype(np.float32)


def _audio_candidates(query_path: str, source_path: str, limit: int = 8) -> list[tuple[float, float]]:
    try:
        from scipy.signal import fftconvolve
        q = _spectrum_features(_extract_audio_array(query_path))
        s = _spectrum_features(_extract_audio_array(source_path))
        if q.shape[0] < 10 or s.shape[0] < q.shape[0]:
            return []
        # Correlate each spectral band across time. Every feature vector has
        # unit norm, so mean correlation is mostly insensitive to gain.
        scores = np.zeros(s.shape[0] - q.shape[0] + 1, dtype=np.float64)
        for band in range(q.shape[1]):
            corr = fftconvolve(s[:, band], q[::-1, band], mode="valid")
            scores += corr[:scores.size]
        scores /= (q.shape[0] * q.shape[1])
        picks: list[tuple[float, float]] = []
        work = scores.copy()
        for _ in range(limit):
            i = int(np.argmax(work))
            score = float(scores[i])
            picks.append((i * 0.1, score))
            work[max(0, i - q.shape[0]): min(len(work), i + q.shape[0])] = -np.inf
        return picks
    except Exception as exc:
        LOG.debug("Audio alignment unavailable: %s", exc)
        return []


def _tokens(transcript_data: list[dict]) -> list[tuple[str, float, float]]:
    out: list[tuple[str, float, float]] = []
    for seg in transcript_data:
        words = seg.get("words") or []
        if words:
            for word in words:
                normalized = re.sub(r"[^\w']", "", str(word.get("word", "")).lower())
                if normalized:
                    out.append((normalized, float(word.get("start", seg.get("start", 0))),
                                float(word.get("end", seg.get("end", 0)))))
        else:
            for token in re.findall(r"[\w']+", str(seg.get("text", "")).lower()):
                out.append((token, float(seg.get("start", 0)), float(seg.get("end", 0))))
    return sorted(out, key=lambda x: x[1])


def _transcript_candidates(clip_transcript: list[dict], source_transcript: list[dict],
                           clip_duration: float, limit: int = 8) -> list[tuple[float, float]]:
    try:
        try:
            from rapidfuzz import fuzz
            ratio = lambda left, right: fuzz.ratio(left, right) / 100.0
        except ImportError:
            from difflib import SequenceMatcher
            ratio = lambda left, right: SequenceMatcher(None, left, right, autojunk=False).ratio()
        q = _tokens(clip_transcript)
        source = _tokens(source_transcript)
        if len(q) < 3 or len(source) < 3:
            return []
        qtext = " ".join(t[0] for t in q)
        # Candidate windows use text duration as a rough scale. Test overlapping
        # windows and keep several repeated-phrase candidates for audio tie-break.
        candidates = []
        step = max(1, len(q) // 5)
        for i in range(0, max(1, len(source) - 2), step):
            for j in (max(i + 2, i + len(q) - 3), min(len(source), i + len(q) + 4)):
                if j > len(source):
                    continue
                text = " ".join(t[0] for t in source[i:j])
                score = ratio(qtext, text)
                if score >= 0.52:
                    start = max(0.0, source[i][1] - max(0.0, q[0][1]) * 0.0)
                    end = source[j - 1][2]
                    if end - start > 0:
                        candidates.append((start, score))
        candidates.sort(key=lambda x: x[1], reverse=True)
        kept: list[tuple[float, float]] = []
        for c in candidates:
            if all(abs(c[0] - prior[0]) > max(2.0, clip_duration * .35) for prior in kept):
                kept.append(c)
                if len(kept) >= limit:
                    break
        return kept
    except Exception as exc:
        LOG.debug("Transcript alignment unavailable: %s", exc)
        return []


def _phash_candidates(query_path: str, source_path: str, clip_duration: float,
                      source_duration: float, limit: int = 6) -> list[tuple[float, float]]:
    """Compare sampled 64-bit perceptual hashes at coarse source offsets."""
    try:
        import cv2
        def frames(path: str, start: float, end: float, count: int) -> list[int]:
            cap = cv2.VideoCapture(path)
            vals = []
            for t in np.linspace(start, max(start, end - 0.08), count):
                cap.set(cv2.CAP_PROP_POS_MSEC, float(t) * 1000)
                ok, frame = cap.read()
                if ok:
                    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                    small = cv2.resize(gray, (32, 32)).astype(np.float32)
                    dct = cv2.dct(small)
                    block = dct[:8, :8].flatten()[1:]
                    med = np.median(block)
                    bits = (block > med).astype(np.uint8)
                    h = 0
                    for b in bits:
                        h = (h << 1) | int(b)
                    vals.append(h)
            cap.release()
            return vals
        q = frames(query_path, 0, clip_duration, 6)
        if len(q) < 3:
            return []
        step = max(0.5, clip_duration / 8)
        starts = np.arange(0, max(0.01, source_duration - clip_duration), step)
        picks = []
        for start in starts:
            s = frames(source_path, float(start), float(start) + clip_duration, len(q))
            if len(s) != len(q):
                continue
            distances = [int(a ^ b).bit_count() for a, b in zip(q, s)]
            confidence = 1.0 - float(np.mean(distances)) / 64.0
            picks.append((float(start), confidence))
        picks.sort(key=lambda x: x[1], reverse=True)
        return picks[:limit]
    except Exception as exc:
        LOG.debug("Visual alignment unavailable: %s", exc)
        return []


def refine_match_timestamps(candidate_start: float, clip_duration: float,
                            source_duration: float, fps: float) -> tuple[float, float]:
    """Clamp and snap a candidate source interval to source-frame boundaries."""
    frame = 1.0 / max(fps, 1.0)
    last_frame = math.floor(source_duration / frame) * frame
    start = min(last_frame, round(max(0.0, candidate_start) / frame) * frame)
    end = min(source_duration, round(min(source_duration, start + clip_duration) / frame) * frame)
    return start, max(start, end)


def match_clip_to_original(clip_path: str, clip: EditedClip, source_info: VideoInfo,
                           source_transcript: list[dict], clip_transcript: list[dict],
                           clip_has_audio: bool = True) -> Optional[Match]:
    """Search the full original and return a confidence-scored source interval."""
    candidates: list[tuple[float, float, str]] = []
    if clip_has_audio and source_info.has_audio:
        candidates.extend((start, score, "audio") for start, score in _audio_candidates(clip_path, source_info.path))
    candidates.extend((start, score, "transcript") for start, score in
                      _transcript_candidates(clip_transcript, source_transcript, clip.duration))
    audio = sorted((c for c in candidates if c[2] == "audio"), key=lambda c: c[1], reverse=True)
    audio_tied = bool(audio and (len(audio) == 1 or
                      audio[0][1] - audio[min(1, len(audio)-1)][1] < 0.04))
    # Visual decoding is comparatively expensive; reserve it for missing/weak
    # audio or nearly tied audio peaks where it can actually disambiguate.
    visual = (_phash_candidates(clip_path, source_info.path, clip.duration, source_info.duration)
              if not audio or audio[0][1] < 0.36 or audio_tied else [])
    candidates.extend((start, score, "visual") for start, score in visual)
    if not candidates:
        return None
    # Audio remains the primary signal. Repeated/tonal audio can have many nearly
    # equal peaks, so use matching frame hashes to disambiguate nearby-tied peaks.
    if audio and audio_tied:
        visual_best = max(visual, key=lambda c: c[1], default=None)
        if visual_best and visual_best[1] >= 0.65:
            tied = [c for c in audio if c[1] >= audio[0][1] - 0.04]
            if tied:
                nearest = min(tied, key=lambda c: abs(c[0] - visual_best[0]))
                candidates.append((nearest[0], nearest[1], "audio+visual"))
    # Evidence priority is explicit; raw scores from different modalities are
    # not comparable. Transcript/visual evidence only leads when audio is absent.
    combined = [c for c in candidates if c[2] == "audio+visual"]
    if combined and combined[0][1] >= 0.36:
        start, score, method = combined[0]
    elif audio and audio[0][1] >= 0.36:
        start, score, method = audio[0]
    else:
        textual = [c for c in candidates if c[2] == "transcript"]
        pool = textual if textual and max(c[1] for c in textual) >= 0.62 else [
            c for c in candidates if c[2] == "visual" and c[1] >= 0.82]
        if not pool:
            return None
        start, score, method = max(pool, key=lambda c: c[1])
    thresholds = {"audio": 0.36, "audio+visual": 0.36, "transcript": 0.62, "visual": 0.82}
    if score < thresholds[method]:
        return None
    start, end = refine_match_timestamps(start, clip.duration, source_info.duration, source_info.fps)
    if end - start < MIN_CLIP:
        return None
    return Match(clip, start, end, max(0.0, min(1.0, score)), method)


def resolve_duplicate_and_overlapping_matches(matches: list[Match]) -> list[Match]:
    """Sort matches and warn on overlap; overlaps are merged for gap math later."""
    ordered = sorted(matches, key=lambda m: (m.original_start, m.original_end))
    for left, right in zip(ordered, ordered[1:]):
        if right.original_start < left.original_end:
            LOG.warning("Matched intervals overlap (%.3f–%.3f and %.3f–%.3f); no gap will be emitted",
                        left.original_start, left.original_end, right.original_start, right.original_end)
    return ordered


def identify_missing_context(matches: list[Match], source_duration: float, min_gap: float = 2.0,
                             tail_seconds: float = 30.0, include_head: bool = False) -> list[ContextClip]:
    """Return gaps between known matches, optionally including head and tail."""
    ordered = sorted(matches, key=lambda m: m.original_start)
    if not ordered:
        return []
    contexts: list[ContextClip] = []
    if include_head and ordered[0].original_start >= min_gap:
        contexts.append(ContextClip(0.0, ordered[0].original_start))
    cursor = ordered[0].original_end
    for match in ordered[1:]:
        if match.original_start > cursor:
            gap = match.original_start - cursor
            if gap >= min_gap:
                contexts.append(ContextClip(cursor, match.original_start))
            else:
                LOG.info("Skipping short context gap %.3fs (below --min-gap %.3fs)", gap, min_gap)
        cursor = max(cursor, match.original_end)
    tail_end = min(source_duration, cursor + max(0.0, tail_seconds))
    if tail_end - cursor >= min_gap:
        contexts.append(ContextClip(cursor, tail_end))
    return contexts


def _probe_output(path: str) -> None:
    data = json.loads(_run(["ffprobe", "-v", "error", "-show_streams", "-of", "json", path]).stdout)
    kinds = {s.get("codec_type") for s in data.get("streams", [])}
    if "video" not in kinds or "audio" not in kinds:
        raise RuntimeError(f"Export is missing an audio or video stream: {path}")


def extract_clip(source_path: str, start: float, end: float, output_path: str,
                 fast: bool = False, source_has_audio: bool = True) -> None:
    """Export one original-source interval and validate its audio/video streams."""
    if end <= start:
        raise ValueError(f"Invalid extraction interval {start}–{end}")
    command = ["ffmpeg", "-y", "-v", "error", "-ss", f"{start:.6f}", "-i", source_path]
    if not source_has_audio:
        command += ["-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=48000"]
    command += ["-t", f"{end-start:.6f}", "-map", "0:v:0", "-map", "0:a:0" if source_has_audio else "1:a:0",
                "-movflags", "+faststart"]
    if fast:
        command += (["-c", "copy"] if source_has_audio else
                    ["-c:v", "copy", "-c:a", "aac", "-b:a", "192k"])
    else:
        command += ["-c:v", "libx264", "-preset", "medium", "-crf", "18", "-c:a", "aac", "-b:a", "192k"]
    command.append(output_path)
    _run(command)
    _probe_output(output_path)


def _stamp(seconds: float) -> str:
    ms = int(round(max(0.0, seconds) * 1000))
    hours, rem = divmod(ms, 3_600_000)
    minutes, rem = divmod(rem, 60_000)
    secs, millis = divmod(rem, 1000)
    return f"{hours:02d}-{minutes:02d}-{secs:02d}.{millis:03d}"


def export_results(source_info: VideoInfo, matches: list[Match], contexts: list[ContextClip],
                   output_dir: str, fast: bool = False) -> list[str]:
    """Export matched and context intervals in original chronology as MP4 only."""
    out_dir = Path(output_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    items: list[tuple[float, float, str]] = [(m.original_start, m.original_end, "matched") for m in matches]
    items.extend((c.start, c.end, "context") for c in contexts)
    items.sort(key=lambda x: (x[0], 0 if x[2] == "matched" else 1))
    paths = []
    for seq, (start, end, kind) in enumerate(items, 1):
        name = f"{seq:03d}_{kind}_{_stamp(start)}_to_{_stamp(end)}.mp4"
        path = str(out_dir / name)
        extract_clip(source_info.path, start, end, path, fast, source_info.has_audio)
        paths.append(path)
    return paths


def _transcribe(fn: Callable[[str], list[dict]], path: str, label: str) -> list[dict]:
    try:
        value = fn(path)
        if not value:
            LOG.warning("Transcript for %s was empty; using other match signals", label)
            return []
        return value
    except Exception as exc:
        LOG.warning("Transcript failed for %s (%s); using other match signals", label, exc)
        return []


def recover(original_path: str, edited_path: str, output_dir: str, *,
            transcript_fn: Optional[Callable[[str], list[dict]]] = None,
            min_gap: float = 2.0, tail_seconds: float = 30.0, include_head: bool = False,
            fast: bool = False, use_transcript: bool = True) -> list[str]:
    original = inspect_video(original_path)
    edited = inspect_video(edited_path)
    if not original.has_video or not edited.has_video:
        raise ValueError("Both inputs must contain video streams")
    if not original.has_audio:
        LOG.warning("Original has no audio; matching will use transcript or visual evidence")
    if not edited.has_audio:
        LOG.warning("Edited input has no audio; audio boundary detection and matching are disabled")
    fn = transcript_fn
    if use_transcript and fn is None:
        try:
            from transcript_module import transcript as fn
        except Exception as exc:
            LOG.warning("Transcript module unavailable (%s); using other match signals", exc)
    source_transcript = _transcribe(fn, original.path, "original") if fn else []
    clips = segment_edited_video(edited.path, edited.duration, edited.has_audio)
    if not clips:
        raise ValueError("No edited clips of at least two seconds were detected")
    matches: list[Match] = []
    with tempfile.TemporaryDirectory(prefix="speech-context-") as td:
        for index, clip in enumerate(clips, 1):
            clip_path = str(Path(td) / f"edited-{index:03d}.mp4")
            extract_clip(edited.path, clip.start, clip.end, clip_path, source_has_audio=edited.has_audio)
            clip_transcript = _transcribe(fn, clip_path, f"edited clip {index}") if fn else []
            match = match_clip_to_original(clip_path, clip, original, source_transcript,
                                           clip_transcript, edited.has_audio)
            if match is None:
                LOG.warning("Could not confidently match edited clip %d (%.3f–%.3f); nearby context may be incomplete",
                            index, clip.start, clip.end)
            else:
                LOG.info("Matched edited clip %d to %.3f–%.3f (confidence %.3f, %s)",
                         index, match.original_start, match.original_end, match.confidence, match.method)
                matches.append(match)
    matches = resolve_duplicate_and_overlapping_matches(matches)
    contexts = identify_missing_context(matches, original.duration, min_gap, tail_seconds, include_head)
    return export_results(original, matches, contexts, output_dir, fast)


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original", help="full original speech MP4")
    parser.add_argument("edited", help="edited/spliced speech MP4")
    parser.add_argument("--output-dir", required=True, help="directory for MP4 exports")
    parser.add_argument("--min-gap", type=float, default=2.0, help="minimum context gap to export (seconds)")
    parser.add_argument("--tail-seconds", type=float, default=30.0, help="context to export after the last match")
    parser.add_argument("--include-head", action="store_true", help="export context before the first match")
    parser.add_argument("--fast", action="store_true", help="stream-copy output; cuts may be keyframe-aligned")
    parser.add_argument("--no-transcript", action="store_true", help="skip transcript provider")
    parser.add_argument("--verbose", action="store_true", help="enable debug logging")
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(levelname)s: %(message)s")
    if args.min_gap < 0 or args.tail_seconds < 0:
        parser.error("--min-gap and --tail-seconds must be nonnegative")
    try:
        outputs = recover(args.original, args.edited, args.output_dir,
                          min_gap=args.min_gap, tail_seconds=args.tail_seconds,
                          include_head=args.include_head, fast=args.fast,
                          use_transcript=not args.no_transcript)
        LOG.info("Wrote %d MP4 file(s) to %s", len(outputs), Path(args.output_dir).resolve())
        return 0
    except Exception as exc:
        LOG.error("Recovery failed: %s", exc)
        return 2


if __name__ == "__main__":
    sys.exit(main())
