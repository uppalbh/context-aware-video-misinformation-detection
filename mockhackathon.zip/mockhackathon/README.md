# Speech context recovery

Finds the original-source intervals used in an edited speech video, then exports
those matched intervals and the missing context between them as separate MP4s.
The matcher uses normalized audio spectrogram alignment first, transcript fuzzy
alignment second, and sampled perceptual frame hashes as a visual fallback.
Scene and audio discontinuities propose edited-video boundaries; candidate
segments that cannot be matched are logged and omitted from gap calculations.

## Requirements

Python 3.11+, FFmpeg (`ffmpeg` and `ffprobe` on `PATH`), and the packages in
`requirements.txt`. Install FFmpeg from <https://ffmpeg.org/download.html> or
with `winget install Gyan.FFmpeg` on Windows. Then run:

```sh
python -m pip install -r requirements.txt
```

The included `transcript_module.py` is an integration stub and raises
`NotImplementedError`. Replace it with the teammate's provider or inject a
callable in Python. If it is unavailable, matching continues with audio and
visual evidence.

## Usage

```sh
python speech_context_recovery.py original.mp4 edited.mp4 --output-dir recovered
```

Optional flags include `--min-gap 2`, `--tail-seconds 30`, `--include-head`,
`--fast`, and `--no-transcript`. Only MP4 files are written to the output
directory; progress and warnings go to the console.

## Matching notes and limitations

Audio frames use normalized log-spectrum features and subsequence correlation,
which tolerates gain and many compression changes. Transcript matching uses
fuzzy text windows when the transcript provider is available. Visual hashes
provide a coarse fallback for silent or ambiguous clips. Strong repeated audio,
very short clips, heavy time stretching, source edits, and poor image/audio
quality can still produce ambiguous matches; weak matches are excluded rather
than guessed. Automatic clip segmentation is heuristic, so review console
warnings and the resulting cuts for unusual transitions.
